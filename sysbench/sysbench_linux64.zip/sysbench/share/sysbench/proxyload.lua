-- for proper initialization use --max-requests = N, where N is --num-threads
--
pathtest = string.match(test, "(.*/)")
local thread_executed = 0

if pathtest then
   dofile(pathtest .. "common.lua")
else
   require("common")
end

function thread_init(thread_id)
   set_vars()
   create_table()
end

function create_table()
   local index_name
   local query

   if (oltp_secondary) then
     index_name = "KEY xid"
   else
     index_name = "PRIMARY KEY"
   end

   if ((db_driver == "mysql") or (db_driver == "attachsql")) then
      query = [[ CREATE TABLE IF NOT EXISTS sbtest1(
		id INTEGER UNSIGNED NOT NULL,
		k INTEGER UNSIGNED DEFAULT '0' NOT NULL,
		c CHAR(120) DEFAULT '' NOT NULL,
		pad CHAR(60) DEFAULT '' NOT NULL,
		]] .. index_name .. [[ (id), KEY k_1(k)
		) /*! ENGINE = ]] .. mysql_table_engine ..
		" MAX_ROWS = " .. myisam_max_rows .. " */ " ..
		(mysql_table_options or "")
   elseif (db_driver == "pgsql") then
      query = [[ CREATE TABLE IF NOT EXISTS sbtest1 (
		id SERIAL NOT NULL,
		k INTEGER DEFAULT '0' NOT NULL,
		c CHAR(120) DEFAULT '' NOT NULL,
		pad CHAR(60) DEFAULT '' NOT NULL,
		]] .. index_name .. [[ (id) , KEY k_1(k)
		) ]]
   elseif (db_driver == "drizzle") then
      query = [[ CREATE TABLE IF NOT EXISTS sbtest1 (
		id INTEGER NOT NULL,
		k INTEGER DEFAULT '0' NOT NULL,
		c CHAR(120) DEFAULT '' NOT NULL,
		pad CHAR(60) DEFAULT '' NOT NULL,
		]] .. index_name .. [[ (id), KEY k_1(k)
		) ]]
   else
      print("Unknown database driver: " .. db_driver)
      return 1
   end

   db_query(query)
end

function proxy_insert(thread_id, numthreads)
   local c_val
   local pad_val
   local query
   local j

   for j=(thread_id + 1), oltp_table_size, numthreads do
       if ((j+0) < oltp_table_size + 1) then
           c_val = sb_rand_str([[###########-###########-###########-###########-###########-###########-###########-###########-###########-###########]])
           pad_val = sb_rand_str([[###########-###########-###########-###########-###########]])
           query = "INSERT INTO sbtest1(id, k, c, pad) VALUES" ..
       		"("..j.."," .. sb_rand(1, oltp_table_size) .. ",'".. c_val .."', '" .. pad_val .. "' )"
           db_query(query)
       end
   end
end

function prepare()
   db_connect()
   create_table()
end

function cleanup()
   db_query("DROP TABLE IF EXISTS sbtest1")
end

function event(thread_id)
   if (thread_executed == 0) then
      proxy_insert(thread_id,num_threads)
      thread_executed = 1
   end
end

